﻿using System;

namespace CSVToJson.Output
{
    /// <summary>
    /// Outputs to XML format
    /// </summary>
    public class XmlOutput<T> : IOutput
    {
        public string Output(object inputObject)
        {
            throw new NotImplementedException();
        }
    }
}
